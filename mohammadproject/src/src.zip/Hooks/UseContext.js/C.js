import React from "react";
import D from "./D";

export default function C() {
  return (
    <>
      <D />;
    </>
  );
}
